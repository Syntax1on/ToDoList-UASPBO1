<?php
// Abstract class for base task
abstract class AbstractTask {
    abstract public function getStatus();
}

// Interface for archivable tasks
interface Archivable {
    public function archive();
}

interface Searchable {
    public function matchesQuery($query);
}

class Task extends AbstractTask implements Archivable, Searchable {
    private $title;
    private $status; // 'ongoing' or 'done'
    private $category;
    private $archived = false;
    private $dueDate;
    private $priority; // 'low', 'normal', 'high'
    private $checklist = [];

    public function __construct($title, $category = null, $dueDate = null, $priority = 'normal', $checklist = []) {
        $this->title = $title;
        $this->status = 'ongoing';
        $this->category = $category;
        $this->dueDate = $dueDate;
        $this->setPriority($priority);
        $this->checklist = $checklist;
    }

    // Encapsulation: Getters and Setters
    public function getTitle() { return $this->title; }
    public function setTitle($title) { $this->title = $title; }
    public function getCategory() { return $this->category; }
    public function setCategory($category) { $this->category = $category; }
    public function isArchived() { return $this->archived; }
    public function getDueDate() { return $this->dueDate; }
    public function setDueDate($dueDate) { $this->dueDate = $dueDate; }
    public function getPriority() { return $this->priority; }
    public function setPriority($priority) {
        $valid = ['low', 'normal', 'high'];
        if (!in_array($priority, $valid)) {
            throw new Exception('Invalid priority');
        }
        $this->priority = $priority;
    }
    public function getChecklist() { return $this->checklist; }
    public function setChecklist($checklist) { $this->checklist = $checklist; }
    public function addChecklistItem($item) { $this->checklist[] = ['text' => $item, 'checked' => false]; }
    public function checkChecklistItem($index) { if (isset($this->checklist[$index])) $this->checklist[$index]['checked'] = true; }

    // Overriding abstract method
    public function getStatus() { return $this->status; }
    public function setStatus($status) {
        if ($status === 'ongoing' || $status === 'done') {
            $this->status = $status;
        } else {
            throw new Exception('Invalid status');
        }
    }
    // Archivable interface
    public function archive() { $this->archived = true; }

    // Searchable interface
    public function matchesQuery($query) {
        return stripos($this->title, $query) !== false;
    }
} 