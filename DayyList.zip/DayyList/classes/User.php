<?php
// Abstract class for user-related actions
abstract class AbstractUser {
    abstract public function getProfile();
}

// Interface for authentication
interface Authenticatable {
    public function login($password);
    public function signup();
}

class User extends AbstractUser implements Authenticatable {
    private static $userCount = 0;
    private $username;
    private $password;
    private $email;
    protected $role;

    public function __construct($username, $password, $email, $role = 'user') {
        $this->username = $username;
        $this->password = $password;
        $this->email = $email;
        $this->role = $role;
        self::$userCount++;
    }

    // Encapsulation: Getters and Setters
    public function getUsername() {
        return $this->username;
    }
    public function setUsername($username) {
        $this->username = $username;
    }
    public function getEmail() {
        return $this->email;
    }
    public function setEmail($email) {
        $this->email = $email;
    }
    public function getRole() {
        return $this->role;
    }
    public function setRole($role) {
        $this->role = $role;
    }
    public static function getUserCount() {
        return self::$userCount;
    }

    // Abstract method implementation
    public function getProfile() {
        return [
            'username' => $this->username,
            'email' => $this->email,
            'role' => $this->role
        ];
    }

    // Interface methods
    public function login($password) {
        if ($this->password === $password) {
            return true;
        } else {
            throw new Exception('Invalid password');
        }
    }
    public function signup() {
        // Minimal: just return true
        return true;
    }
} 