<?php
class Checklist {
    private $items = [];
    private $checked = [];

    public function __construct($items = []) {
        $this->items = $items;
        $this->checked = array_fill(0, count($items), false);
    }
    public function addItem($item) {
        $this->items[] = $item;
        $this->checked[] = false;
    }
    public function checkItem($index) {
        if (isset($this->checked[$index])) {
            $this->checked[$index] = true;
        } else {
            throw new Exception('Invalid checklist item');
        }
    }
    public function getItems() {
        return $this->items;
    }
    public function getChecked() {
        return $this->checked;
    }
} 