<?php
// Abstract class for base task
abstract class AbstractTask {
    abstract public function getStatus();
}

// Interface for archivable tasks
interface Archivable {
    public function archive();
}

class Task extends AbstractTask implements Archivable {
    private $title;
    private $status; // 'ongoing' or 'done'
    private $category;
    private $archived = false;

    public function __construct($title, $category = null) {
        $this->title = $title;
        $this->status = 'ongoing';
        $this->category = $category;
    }

    // Encapsulation: Getters and Setters
    public function getTitle() {
        return $this->title;
    }
    public function setTitle($title) {
        $this->title = $title;
    }
    public function getCategory() {
        return $this->category;
    }
    public function setCategory($category) {
        $this->category = $category;
    }
    public function isArchived() {
        return $this->archived;
    }

    // Overriding abstract method
    public function getStatus() {
        return $this->status;
    }
    public function setStatus($status) {
        if ($status === 'ongoing' || $status === 'done') {
            $this->status = $status;
        } else {
            throw new Exception('Invalid status');
        }
    }
    // Archivable interface
    public function archive() {
        $this->archived = true;
    }
} 