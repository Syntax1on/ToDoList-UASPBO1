<?php
session_start();
// Autoload classes
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/classes/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Minimal in-memory data for demo (replace with JSON in real app)
if (!isset($_SESSION['users'])) $_SESSION['users'] = [];
if (!isset($_SESSION['tasks'])) $_SESSION['tasks'] = [];
if (!isset($_SESSION['categories'])) $_SESSION['categories'] = [];
if (!isset($_SESSION['checklist'])) $_SESSION['checklist'] = [];

// Handle signup
$signup_error = '';
if (isset($_POST['signup'])) {
    try {
        $user = new User($_POST['username'], $_POST['password'], $_POST['email']);
        $_SESSION['users'][$_POST['username']] = serialize($user);
        $_SESSION['user'] = $_POST['username'];
    } catch (Exception $e) {
        $signup_error = $e->getMessage();
    }
}
// Handle login
$login_error = '';
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if (isset($_SESSION['users'][$username])) {
        $user = unserialize($_SESSION['users'][$username]);
        try {
            if ($user->login($password)) {
                $_SESSION['user'] = $username;
            }
        } catch (Exception $e) {
            $login_error = $e->getMessage();
        }
    } else {
        $login_error = 'User not found';
    }
}
// Handle add task
if (isset($_POST['add_task'])) {
    $task = new Task($_POST['task_title'], $_POST['task_category'] ?? null);
    $_SESSION['tasks'][] = serialize($task);
}
// Handle task progress
if (isset($_POST['set_done'])) {
    $idx = $_POST['set_done'];
    $task = unserialize($_SESSION['tasks'][$idx]);
    $task->setStatus('done');
    $_SESSION['tasks'][$idx] = serialize($task);
}
// Handle archive
if (isset($_POST['archive'])) {
    $idx = $_POST['archive'];
    $task = unserialize($_SESSION['tasks'][$idx]);
    $task->archive();
    $_SESSION['tasks'][$idx] = serialize($task);
}
// Handle add category
if (isset($_POST['add_category'])) {
    $cat = new Category($_POST['category_name']);
    $_SESSION['categories'][] = serialize($cat);
}
// Handle add checklist item
if (isset($_POST['add_checklist'])) {
    $_SESSION['checklist'][] = $_POST['checklist_item'];
}
// Handle check checklist item
if (isset($_POST['check_item'])) {
    $idx = $_POST['check_item'];
    $_SESSION['checklist_checked'][$idx] = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DayyList Minimal App</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <header>
        <h1>DayyList Minimal App</h1>
        <nav>
            <a href="?page=dashboard">Dashboard</a> |
            <a href="?page=profile">Profile</a> |
            <a href="?page=tasks">Tasks</a> |
            <a href="?page=categories">Categories</a> |
            <a href="?page=checklist">Checklist</a> |
            <a href="?page=pomodoro">Pomodoro</a> |
            <a href="?page=archive">Archive</a> |
            <a href="?page=account">Account Settings</a> |
            <a href="?page=login">Login/Signup</a>
        </nav>
    </header>
    <main>
        <?php
        $page = $_GET['page'] ?? 'dashboard';
        switch ($page) {
            case 'profile':
                echo '<h2>Profile Management (Anas)</h2>';
                if (isset($_SESSION['user'])) {
                    $user = unserialize($_SESSION['users'][$_SESSION['user']]);
                    $profile = $user->getProfile();
                    echo '<p>Username: ' . htmlspecialchars($profile['username']) . '</p>';
                    echo '<p>Email: ' . htmlspecialchars($profile['email']) . '</p>';
                    echo '<p>Role: ' . htmlspecialchars($profile['role']) . '</p>';
                } else {
                    echo '<p>Please log in.</p>';
                }
                break;
            case 'tasks':
                echo '<h2>Task Management (Hana)</h2>';
                echo '<form method="post"><input name="task_title" placeholder="Task title" required> ';
                echo '<select name="task_category"><option value="">No Category</option>';
                foreach ($_SESSION['categories'] as $cat) {
                    $catObj = unserialize($cat);
                    echo '<option value="' . htmlspecialchars($catObj->getName()) . '">' . htmlspecialchars($catObj->getName()) . '</option>';
                }
                echo '</select> <button name="add_task">Add Task</button></form>';
                echo '<ul>';
                foreach ($_SESSION['tasks'] as $i => $task) {
                    $taskObj = unserialize($task);
                    if (!$taskObj->isArchived()) {
                        echo '<li>' . htmlspecialchars($taskObj->getTitle()) . ' [' . htmlspecialchars($taskObj->getStatus()) . ']';
                        if ($taskObj->getStatus() === 'ongoing') {
                            echo ' <form style="display:inline" method="post"><button name="set_done" value="' . $i . '">Mark Done</button></form>';
                        }
                        echo ' <form style="display:inline" method="post"><button name="archive" value="' . $i . '">Archive</button></form>';
                        echo '</li>';
                    }
                }
                echo '</ul>';
                break;
            case 'categories':
                echo '<h2>Category Management (Anas)</h2>';
                echo '<form method="post"><input name="category_name" placeholder="Category name" required> <button name="add_category">Add Category</button></form>';
                echo '<ul>';
                foreach ($_SESSION['categories'] as $cat) {
                    $catObj = unserialize($cat);
                    echo '<li>' . htmlspecialchars($catObj->getName()) . '</li>';
                }
                echo '</ul>';
                break;
            case 'checklist':
                echo '<h2>Checklist Integration (Anas)</h2>';
                echo '<form method="post"><input name="checklist_item" placeholder="Checklist item" required> <button name="add_checklist">Add</button></form>';
                echo '<ul>';
                foreach ($_SESSION['checklist'] as $i => $item) {
                    $checked = isset($_SESSION['checklist_checked'][$i]) && $_SESSION['checklist_checked'][$i];
                    echo '<li>';
                    echo $checked ? '<s>' . htmlspecialchars($item) . '</s>' : htmlspecialchars($item);
                    if (!$checked) {
                        echo ' <form style="display:inline" method="post"><button name="check_item" value="' . $i . '">Check</button></form>';
                    }
                    echo '</li>';
                }
                echo '</ul>';
                break;
            case 'pomodoro':
                echo '<h2>Pomodoro Timer (Hana)</h2>';
                echo '<p><em>Minimal placeholder: Timer not implemented.</em></p>';
                break;
            case 'archive':
                echo '<h2>Archive Tasks (Hana)</h2>';
                echo '<ul>';
                foreach ($_SESSION['tasks'] as $task) {
                    $taskObj = unserialize($task);
                    if ($taskObj->isArchived()) {
                        echo '<li>' . htmlspecialchars($taskObj->getTitle()) . ' [' . htmlspecialchars($taskObj->getStatus()) . ']</li>';
                    }
                }
                echo '</ul>';
                break;
            case 'account':
                echo '<h2>Account Settings (Anas)</h2>';
                echo '<p><em>Minimal placeholder.</em></p>';
                break;
            case 'login':
                echo '<h2>Sign-Up & Login (Syea)</h2>';
                if (!isset($_SESSION['user'])) {
                    echo '<form method="post"><h3>Sign Up</h3>';
                    echo '<input name="username" placeholder="Username" required> ';
                    echo '<input name="email" placeholder="Email" required> ';
                    echo '<input name="password" type="password" placeholder="Password" required> ';
                    echo '<button name="signup">Sign Up</button>';
                    if ($signup_error) echo '<p style="color:red">' . htmlspecialchars($signup_error) . '</p>';
                    echo '</form>';
                    echo '<form method="post"><h3>Login</h3>';
                    echo '<input name="username" placeholder="Username" required> ';
                    echo '<input name="password" type="password" placeholder="Password" required> ';
                    echo '<button name="login">Login</button>';
                    if ($login_error) echo '<p style="color:red">' . htmlspecialchars($login_error) . '</p>';
                    echo '</form>';
                } else {
                    echo '<p>Logged in as ' . htmlspecialchars($_SESSION['user']) . '.</p>';
                }
                break;
            default:
                echo '<h2>Dashboard (Syea)</h2>';
                if (isset($_SESSION['user'])) {
                    echo '<p>Welcome, ' . htmlspecialchars($_SESSION['user']) . '!</p>';
                } else {
                    echo '<p>Welcome! Please <a href="?page=login">log in</a>.</p>';
                }
        }
        ?>
    </main>
</body>
</html> 