<?php
// Autoload classes
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/classes/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

function read_json($filename) {
    $path = __DIR__ . '/data/' . $filename;
    if (!file_exists($path)) return [];
    $json = file_get_contents($path);
    $data = json_decode($json, true);
    return $data ?: [];
}
function write_json($filename, $data) {
    $path = __DIR__ . '/data/' . $filename;
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT));
}

$users = read_json('users.json');
$tasks = read_json('tasks.json');
$categories = read_json('categories.json');

session_start();

$signup_error = '';
if (isset($_POST['signup'])) {
    try {
        $user = new User($_POST['username'], $_POST['password'], $_POST['email']);
        $users[$_POST['username']] = serialize($user);
        $_SESSION['user'] = $_POST['username'];
        write_json('users.json', $users);
    } catch (Exception $e) {
        $signup_error = $e->getMessage();
    }
}
$login_error = '';
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if (isset($users[$username])) {
        $user = unserialize($users[$username]);
        try {
            if ($user->login($password)) {
                $_SESSION['user'] = $username;
            }
        } catch (Exception $e) {
            $login_error = $e->getMessage();
        }
    } else {
        $login_error = 'User not found';
    }
}
// Add or edit task
if (isset($_POST['add_task'])) {
    $title = $_POST['task_title'];
    $category = $_POST['task_category'] ?? null;
    $dueDate = $_POST['task_due'] ?? null;
    $priority = $_POST['task_priority'] ?? 'normal';
    $checklist = [];
    if (!empty($_POST['checklist_item'])) {
        foreach ($_POST['checklist_item'] as $item) {
            if (trim($item) !== '') $checklist[] = ['text' => $item, 'checked' => false];
        }
    }
    $task = new Task($title, $category, $dueDate, $priority, $checklist);
    $tasks[] = serialize($task);
    write_json('tasks.json', $tasks);
}
// Add/Edit task logic
if (isset($_POST['edit_task_save'])) {
    $idx = $_POST['edit_task_idx'];
    $title = $_POST['edit_task_title'];
    $category = $_POST['edit_task_category'] ?? null;
    $dueDate = $_POST['edit_task_due'] ?? null;
    $priority = $_POST['edit_task_priority'] ?? 'normal';
    $checklist = [];
    if (!empty($_POST['edit_checklist_item'])) {
        foreach ($_POST['edit_checklist_item'] as $i => $item) {
            if (trim($item) !== '') {
                $checked = isset($_POST['edit_checklist_checked'][$i]) ? true : false;
                $checklist[] = ['text' => $item, 'checked' => $checked];
            }
        }
    }
    $task = unserialize($tasks[$idx]);
    $task->setTitle($title);
    $task->setCategory($category);
    $task->setDueDate($dueDate);
    $task->setPriority($priority);
    $task->setChecklist($checklist);
    $tasks[$idx] = serialize($task);
    write_json('tasks.json', $tasks);
}
// Task actions
if (isset($_POST['set_done'])) {
    $idx = $_POST['set_done'];
    $task = unserialize($tasks[$idx]);
    $task->setStatus('done');
    $tasks[$idx] = serialize($task);
    write_json('tasks.json', $tasks);
}
if (isset($_POST['archive'])) {
    $idx = $_POST['archive'];
    $task = unserialize($tasks[$idx]);
    $task->archive();
    $tasks[$idx] = serialize($task);
    write_json('tasks.json', $tasks);
}
if (isset($_POST['delete'])) {
    $idx = $_POST['delete'];
    array_splice($tasks, $idx, 1);
    write_json('tasks.json', $tasks);
}
// Add category
if (isset($_POST['add_category'])) {
    $cat = new Category($_POST['category_name']);
    $categories[] = serialize($cat);
    write_json('categories.json', $categories);
}
// Handle category edit/delete
if (isset($_POST['delete_category'])) {
    $delIdx = $_POST['delete_category'];
    array_splice($categories, $delIdx, 1);
    write_json('categories.json', $categories);
    echo "<script>showToast('Category deleted!','success');</script>";
}
if (isset($_POST['edit_category_save'])) {
    $editIdx = $_POST['edit_category_idx'];
    $cat = unserialize($categories[$editIdx]);
    $cat->setName($_POST['edit_category_name']);
    $categories[$editIdx] = serialize($cat);
    write_json('categories.json', $categories);
    echo "<script>showToast('Category updated!','success');</script>";
}
// Handle profile update (picture, email, password)
if (isset($_POST['update_profile']) && isset($_SESSION['user'])) {
    $username = $_SESSION['user'];
    $user = unserialize($users[$username]);
    // Handle email update
    if (!empty($_POST['profile_email'])) {
        $user->setEmail($_POST['profile_email']);
    }
    // Handle password update
    if (!empty($_POST['profile_password'])) {
        $ref = new ReflectionClass($user);
        $prop = $ref->getProperty('password');
        $prop->setAccessible(true);
        $prop->setValue($user, $_POST['profile_password']);
    }
    // Handle profile picture upload
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
        $filename = $username . '_' . time() . '.' . $ext;
        $target = __DIR__ . '/profile_pics/' . $filename;
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target);
        $userPic = $filename;
        // Save filename in user object (add property if not exists)
        $ref = new ReflectionClass($user);
        if (!$ref->hasProperty('profilePic')) {
            $prop = $ref->getProperty('username'); // dummy to add
            $user->profilePic = $filename;
        } else {
            $user->profilePic = $filename;
        }
    }
    // Save user
    $users[$username] = serialize($user);
    write_json('users.json', $users);
}
// Handle clear all data
if (isset($_POST['clear_all_data'])) {
    file_put_contents(__DIR__ . '/tasks.json', json_encode([]));
    file_put_contents(__DIR__ . '/categories.json', json_encode([]));
    file_put_contents(__DIR__ . '/users.json', json_encode([]));
    // Optionally clear profile_pics directory
    $files = glob(__DIR__ . '/profile_pics/*');
    foreach ($files as $file) { if (is_file($file)) unlink($file); }
    session_destroy();
    header('Location: ?page=settings&cleared=1');
    exit;
}
// Handle logout
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: ?page=login');
    exit;
}
// Tab logic
$activeTab = $_GET['tab'] ?? 'ongoing';
function filter_tasks($tasks, $status, $archived = false) {
    $result = [];
    foreach ($tasks as $i => $task) {
        $taskObj = unserialize($task);
        if ($taskObj->getStatus() === $status && $taskObj->isArchived() === $archived) {
            $result[$i] = $taskObj;
        }
    }
    return $result;
}
function filter_archived($tasks) {
    $result = [];
    foreach ($tasks as $i => $task) {
        $taskObj = unserialize($task);
        if ($taskObj->isArchived()) {
            $result[$i] = $taskObj;
        }
    }
    return $result;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DayyList Modern App</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        darkMode: 'class',
      }
    </script>
</head>
<body class="bg-gray-100 dark:bg-gray-900 min-h-screen">
<header class="bg-blue-500 dark:bg-blue-800 text-white py-8 px-4 shadow">
    <div class="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <h1 class="text-3xl font-bold tracking-wide mb-2 md:mb-0">DayyList Modern App</h1>
        <nav class="flex flex-wrap gap-4 text-lg font-medium items-center">
            <a href="?page=dashboard" class="hover:underline">Dashboard</a>
            <span class="hidden md:inline">|</span>
            <a href="?page=profile" class="hover:underline">Profile</a>
            <span class="hidden md:inline">|</span>
            <a href="?page=categories" class="hover:underline">Categories</a>
            <span class="hidden md:inline">|</span>
            <a href="?page=settings" class="hover:underline">Settings</a>
            <span class="hidden md:inline">|</span>
            <a href="?page=login" class="hover:underline">Login/Signup</a>
            <?php if (isset($_SESSION['user'])): ?>
                <form method="post" class="inline ml-2"><button name="logout" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded">Logout</button></form>
            <?php endif; ?>
        </nav>
        <button id="darkModeToggle" title="Toggle dark mode" class="ml-2 text-yellow-300 text-2xl bg-transparent border-none focus:outline-none">🌙</button>
    </div>
</header>
<main class="max-w-2xl mx-auto py-8 px-2">
<?php
$page = $_GET['page'] ?? 'dashboard';
switch ($page) {
    case 'tasks':
        echo '<h2 class="text-2xl font-bold mb-6 text-blue-600 dark:text-blue-300">Tasks</h2>';
        echo '<div class="tabs">';
        echo '<button class="tab' . ($activeTab === 'ongoing' ? ' active' : '') . '" onclick="switchTab(\'ongoing\')">Ongoing</button>';
        echo '<button class="tab' . ($activeTab === 'done' ? ' active' : '') . '" onclick="switchTab(\'done\')">Done</button>';
        echo '<button class="tab' . ($activeTab === 'archived' ? ' active' : '') . '" onclick="switchTab(\'archived\')">Archived</button>';
        echo '</div>';
        // Task lists
        echo '<div class="task-list" id="task-list">';
        if ($activeTab === 'ongoing') {
            $ongoing = filter_tasks($tasks, 'ongoing', false);
            if (empty($ongoing)) echo '<p>No ongoing tasks.</p>';
            foreach ($ongoing as $i => $task) {
                $progress = count($task->getChecklist()) ? (array_sum(array_column($task->getChecklist(), 'checked')) . '/' . count($task->getChecklist())) : '';
                echo '<div class="task-card">';
                echo '<div class="task-title">' . htmlspecialchars($task->getTitle()) . '</div>';
                echo '<div class="task-meta">';
                if ($task->getDueDate()) echo '<span class="due-date">Due: ' . htmlspecialchars($task->getDueDate()) . '</span>';
                echo '<span class="priority ' . htmlspecialchars($task->getPriority()) . '">' . ucfirst($task->getPriority()) . '</span>';
                if ($progress) echo '<span class="checklist-progress">Checklist: ' . $progress . '</span>';
                echo '</div>';
                echo '<div class="task-actions">';
                echo '<form method="post" style="display:inline"><button title="Mark Done" name="set_done" value="' . $i . '">&#10003;</button></form>';
                echo '<form method="post" style="display:inline"><button title="Archive" name="archive" value="' . $i . '">&#128465;</button></form>';
                echo '<form method="post" style="display:inline"><button title="Delete" name="delete" value="' . $i . '">&#10060;</button></form>';
                echo '<button class="edit-btn" data-idx="' . $i . '">✏️</button>';
                echo '</div>';
                echo '</div>';
            }
        } elseif ($activeTab === 'done') {
            $done = filter_tasks($tasks, 'done', false);
            if (empty($done)) echo '<p>No completed tasks.</p>';
            foreach ($done as $i => $task) {
                $progress = count($task->getChecklist()) ? (array_sum(array_column($task->getChecklist(), 'checked')) . '/' . count($task->getChecklist())) : '';
                echo '<div class="task-card">';
                echo '<div class="task-title">' . htmlspecialchars($task->getTitle()) . '</div>';
                echo '<div class="task-meta">';
                if ($task->getDueDate()) echo '<span class="due-date">Due: ' . htmlspecialchars($task->getDueDate()) . '</span>';
                echo '<span class="priority ' . htmlspecialchars($task->getPriority()) . '">' . ucfirst($task->getPriority()) . '</span>';
                if ($progress) echo '<span class="checklist-progress">Checklist: ' . $progress . '</span>';
                echo '</div>';
                echo '<div class="task-actions">';
                echo '<form method="post" style="display:inline"><button title="Archive" name="archive" value="' . $i . '">&#128465;</button></form>';
                echo '<form method="post" style="display:inline"><button title="Delete" name="delete" value="' . $i . '">&#10060;</button></form>';
                echo '<button class="edit-btn" data-idx="' . $i . '">✏️</button>';
                echo '</div>';
                echo '</div>';
            }
        } elseif ($activeTab === 'archived') {
            $archived = filter_archived($tasks);
            if (empty($archived)) echo '<p>No archived tasks.</p>';
            foreach ($archived as $i => $task) {
                $progress = count($task->getChecklist()) ? (array_sum(array_column($task->getChecklist(), 'checked')) . '/' . count($task->getChecklist())) : '';
                echo '<div class="task-card">';
                echo '<div class="task-title">' . htmlspecialchars($task->getTitle()) . '</div>';
                echo '<div class="task-meta">';
                if ($task->getDueDate()) echo '<span class="due-date">Due: ' . htmlspecialchars($task->getDueDate()) . '</span>';
                echo '<span class="priority ' . htmlspecialchars($task->getPriority()) . '">' . ucfirst($task->getPriority()) . '</span>';
                if ($progress) echo '<span class="checklist-progress">Checklist: ' . $progress . '</span>';
                echo '</div>';
                echo '<div class="task-actions">';
                echo '<form method="post" style="display:inline"><button title="Delete" name="delete" value="' . $i . '">&#10060;</button></form>';
                echo '<button class="edit-btn" data-idx="' . $i . '">✏️</button>';
                echo '</div>';
                echo '</div>';
            }
        }
        echo '</div>';
        // Floating Add Task Button
        echo '<button class="fab" id="openAddModal" title="Add Task">+</button>';
        // Add Task Modal
        echo '<div class="modal" id="addTaskModal">';
        echo '<div class="modal-content">';
        echo '<button class="modal-close" id="closeAddModal">&times;</button>';
        echo '<h3>Add Task</h3>';
        echo '<form method="post" id="addTaskForm">';
        echo '<input name="task_title" placeholder="Task title" required> ';
        echo '<input name="task_due" type="date" placeholder="Due date"> ';
        echo '<select name="task_priority">';
        echo '<option value="normal">Normal</option><option value="low">Low</option><option value="high">High</option>';
        echo '</select> ';
        echo '<select name="task_category"><option value="">No Category</option>';
        foreach ($categories as $cat) {
            $catObj = unserialize($cat);
            echo '<option value="' . htmlspecialchars($catObj->getName()) . '">' . htmlspecialchars($catObj->getName()) . '</option>';
        }
        echo '</select> ';
        echo '<div id="checklistFields">';
        echo '<input name="checklist_item[]" placeholder="Checklist item">';
        echo '</div>';
        echo '<button type="button" id="addChecklistField">+ Checklist Item</button>';
        echo '<button name="add_task">Add Task</button>';
        echo '</form>';
        echo '</div></div>';
        // After the Add Task Modal, add the Edit Task Modal (hidden by default)
        echo '<div class="modal" id="editTaskModal">';
        echo '<div class="modal-content">';
        echo '<button class="modal-close" id="closeEditModal">&times;</button>';
        echo '<h3>Edit Task</h3>';
        echo '<form method="post" id="editTaskForm">';
        echo '<input type="hidden" name="edit_task_idx" id="edit_task_idx">';
        echo '<input name="edit_task_title" id="edit_task_title" placeholder="Task title" required> ';
        echo '<input name="edit_task_due" id="edit_task_due" type="date" placeholder="Due date"> ';
        echo '<select name="edit_task_priority" id="edit_task_priority">';
        echo '<option value="normal">Normal</option><option value="low">Low</option><option value="high">High</option>';
        echo '</select> ';
        echo '<select name="edit_task_category" id="edit_task_category"><option value="">No Category</option>';
        foreach ($categories as $cat) {
            $catObj = unserialize($cat);
            echo '<option value="' . htmlspecialchars($catObj->getName()) . '">' . htmlspecialchars($catObj->getName()) . '</option>';
        }
        echo '</select> ';
        echo '<div id="editChecklistFields"></div>';
        echo '<button type="button" id="addEditChecklistField">+ Checklist Item</button>';
        echo '<button name="edit_task_save">Save Changes</button>';
        echo '</form>';
        echo '</div></div>';
        break;
    case 'categories':
        echo '<h2 class="text-2xl font-bold mb-6 text-blue-600 dark:text-blue-300 text-center">Category Management</h2>';
        echo '<div class="max-w-lg mx-auto bg-white dark:bg-gray-800 dark:text-gray-100 rounded-xl shadow p-8 flex flex-col gap-6">';
        echo '<form method="post" class="flex gap-2 mb-4">';
        echo '<input name="category_name" placeholder="Category name" required class="flex-1 rounded border-gray-300 dark:bg-gray-700 dark:text-white">';
        echo '<button name="add_category" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded">Add Category</button>';
        echo '</form>';
        echo '<ul class="divide-y divide-gray-200 dark:divide-gray-700">';
        foreach ($categories as $i => $cat) {
            $catObj = unserialize($cat);
            echo '<li class="py-2 px-1 flex items-center justify-between">';
            echo '<span>' . htmlspecialchars($catObj->getName()) . '</span>';
            echo '<form method="post" class="flex gap-1 items-center">';
            echo '<input type="hidden" name="edit_category_idx" value="' . $i . '">';
            echo '<input name="edit_category_name" value="' . htmlspecialchars($catObj->getName()) . '" class="rounded border-gray-300 dark:bg-gray-700 dark:text-white w-28">';
            echo '<button name="edit_category_save" class="bg-green-500 hover:bg-green-600 text-white px-2 py-1 rounded">Save</button>';
            echo '<button name="delete_category" value="' . $i . '" onclick="return confirm(\'Delete this category?\')" class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded">Delete</button>';
            echo '</form>';
            echo '</li>';
        }
        echo '</ul>';
        echo '</div>';
        break;
    case 'profile':
        echo '<h2 class="text-2xl font-bold mb-6 text-blue-600 dark:text-blue-300">Profile</h2>';
        if (isset($_SESSION['user']) && isset($users[$_SESSION['user']])) {
            $user = unserialize($users[$_SESSION['user']]);
            $profile = $user->getProfile();
            $pic = isset($user->profilePic) && $user->profilePic && file_exists(__DIR__ . '/profile_pics/' . $user->profilePic)
                ? 'profile_pics/' . $user->profilePic
                : 'https://ui-avatars.com/api/?name=' . urlencode($profile['username']);
            echo '<div class="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-2xl shadow-lg p-8 flex flex-col items-center">';
            echo '<img src="' . $pic . '" alt="Profile Picture" class="w-24 h-24 rounded-full object-cover mb-4 border-4 border-blue-200 dark:border-blue-700">';
            echo '<h3 class="text-xl font-semibold mb-1">' . htmlspecialchars($profile['username']) . '</h3>';
            echo '<p class="text-gray-500 dark:text-gray-300 mb-4">' . htmlspecialchars($profile['email']) . '</p>';
            echo '<form method="post" enctype="multipart/form-data" class="w-full max-w-xs flex flex-col gap-4">';
            echo '<label class="block text-left">Change profile picture:<input type="file" name="profile_pic" accept="image/*" class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"></label>';
            echo '<label class="block text-left">Email:<input type="email" name="profile_email" value="' . htmlspecialchars($profile['email']) . '" class="mt-1 block w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white"></label>';
            echo '<label class="block text-left">New Password:<input type="password" name="profile_password" placeholder="Leave blank to keep current" class="mt-1 block w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white"></label>';
            echo '<button name="update_profile" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg transition">Update Profile</button>';
            echo '</form>';
            echo '</div>';
        } else {
            echo '<div class="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-2xl shadow-lg p-8 flex flex-col items-center">';
            echo '<h3 class="text-xl font-semibold mb-2">Profile</h3>';
            echo '<p class="text-gray-500 dark:text-gray-300">Please log in.</p>';
            echo '</div>';
        }
        break;
    case 'settings':
        echo '<h2>App Settings</h2>';
        if (isset($_GET['cleared'])) echo '<p style="color:green">All data cleared!</p>';
        echo '<form id="settingsForm" style="max-width:400px;margin:2rem auto;background:#fff;padding:2rem 1.5rem;border-radius:16px;box-shadow:0 4px 24px rgba(79,140,255,0.10);">';
        echo '<label style="display:block;margin-bottom:1rem;">Dark Mode: <input type="checkbox" id="settingsDarkMode"></label>';
        echo '<label style="display:block;margin-bottom:1rem;">Default Task View: <select id="settingsDefaultTab"><option value="ongoing">Ongoing</option><option value="done">Done</option><option value="archived">Archived</option></select></label>';
        echo '<label style="display:block;margin-bottom:1rem;">Pomodoro Length (minutes): <input type="number" id="settingsPomoLength" min="5" max="60" value="25"></label>';
        echo '<button type="button" id="saveSettings">Save Settings</button>';
        echo '</form>';
        echo '<form method="post" style="max-width:400px;margin:2rem auto;text-align:center;">';
        echo '<button name="clear_all_data" style="background:#ff5252;color:#fff;padding:0.7rem 1.5rem;border:none;border-radius:8px;cursor:pointer;">Clear All Data</button>';
        echo '</form>';
        break;
    case 'login':
        echo '<h2>Sign-Up & Login</h2>';
        if (!isset($_SESSION['user'])) {
            echo '<form method="post"><h3>Sign Up</h3>';
            echo '<input name="username" placeholder="Username" required> ';
            echo '<input name="email" placeholder="Email" required> ';
            echo '<input name="password" type="password" placeholder="Password" required> ';
            echo '<button name="signup">Sign Up</button>';
            if ($signup_error) echo '<p style="color:red">' . htmlspecialchars($signup_error) . '</p>';
            echo '</form>';
            echo '<form method="post"><h3>Login</h3>';
            echo '<input name="username" placeholder="Username" required> ';
            echo '<input name="password" type="password" placeholder="Password" required> ';
            echo '<button name="login">Login</button>';
            if ($login_error) echo '<p style="color:red">' . htmlspecialchars($login_error) . '</p>';
            echo '</form>';
        } else {
            echo '<p>Logged in as ' . htmlspecialchars($_SESSION['user']) . '.</p>';
        }
        break;
    case 'dashboard':
        echo '<h2 class="text-2xl font-bold mb-6 text-blue-600 dark:text-blue-300">Dashboard</h2>';
        echo '<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">';
        // Add Task Card
        echo '<div class="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-xl shadow p-6 flex flex-col gap-4">';
        echo '<h3 class="text-lg font-semibold mb-2">Add Task</h3>';
        echo '<form method="post" id="dashboardAddTaskForm" class="flex flex-col gap-3">';
        echo '<input name="task_title" placeholder="Task title" required class="rounded border-gray-300 dark:bg-gray-700 dark:text-white">';
        echo '<input name="task_due" type="date" placeholder="Due date" class="rounded border-gray-300 dark:bg-gray-700 dark:text-white">';
        echo '<div class="flex gap-2">';
        echo '<select name="task_priority" class="rounded border-gray-300 dark:bg-gray-700 dark:text-white">';
        echo '<option value="normal">Normal</option><option value="low">Low</option><option value="high">High</option>';
        echo '</select>';
        echo '<select name="task_category" class="rounded border-gray-300 dark:bg-gray-700 dark:text-white"><option value="">No Category</option>';
        foreach ($categories as $cat) {
            $catObj = unserialize($cat);
            echo '<option value="' . htmlspecialchars($catObj->getName()) . '">' . htmlspecialchars($catObj->getName()) . '</option>';
        }
        echo '</select>';
        echo '</div>';
        echo '<div id="dashboardChecklistFields" class="flex flex-col gap-2">';
        echo '<input name="checklist_item[]" placeholder="Checklist item" class="rounded border-gray-300 dark:bg-gray-700 dark:text-white">';
        echo '</div>';
        echo '<div class="flex gap-2">';
        echo '<button type="button" id="dashboardAddChecklistField" class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 px-3 py-1 rounded hover:bg-gray-300 dark:hover:bg-gray-600">+ Checklist Item</button>';
        echo '<button name="add_task" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded">Add Task</button>';
        echo '</div>';
        echo '</form>';
        echo '</div>';
        // Task Categories Card
        echo '<div class="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-xl shadow p-6 flex flex-col gap-4">';
        echo '<h3 class="text-lg font-semibold mb-2">Task Categories</h3>';
        echo '<form method="post" class="flex gap-2 mb-2">';
        echo '<input name="category_name" placeholder="Category name" required class="rounded border-gray-300 dark:bg-gray-700 dark:text-white">';
        echo '<button name="add_category" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded">Add Category</button>';
        echo '</form>';
        echo '<ul class="list-disc pl-5">';
        foreach ($categories as $cat) {
            $catObj = unserialize($cat);
            echo '<li>' . htmlspecialchars($catObj->getName()) . '</li>';
        }
        echo '</ul>';
        echo '</div>';
        echo '</div>';
        // Task List Table
        echo '<div class="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-xl shadow p-6 mb-8">';
        echo '<h3 class="text-lg font-semibold mb-4">Task List</h3>';
        echo '<input id="taskSearch" type="text" placeholder="Search tasks..." class="mb-4 w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white px-3 py-2">';
        $ongoing = filter_tasks($tasks, 'ongoing', false);
        $done = filter_tasks($tasks, 'done', false);
        $archived = filter_archived($tasks);
        echo '<div class="tabs flex gap-2 mb-4">';
        echo '<button class="tab active bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 px-3 py-1 rounded" onclick="dashboardSwitchTab(\'ongoing\')">Ongoing</button>';
        echo '<button class="tab bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 px-3 py-1 rounded" onclick="dashboardSwitchTab(\'done\')">Done</button>';
        echo '<button class="tab bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 px-3 py-1 rounded" onclick="dashboardSwitchTab(\'archived\')">Archived</button>';
        echo '</div>';
        echo '<div id="dashboard-task-list">';
        foreach (["ongoing" => $ongoing, "done" => $done, "archived" => $archived] as $tab => $list) {
            echo '<div class="dashboard-task-tab" data-tab="' . $tab . '" style="display:' . ($tab === 'ongoing' ? 'block' : 'none') . '">';
            if (empty($list)) {
                echo '<p class="text-gray-500 dark:text-gray-400">No tasks.</p>';
            } else {
                echo '<table class="min-w-full text-sm"><thead><tr class="border-b border-gray-200 dark:border-gray-700">';
                echo '<th class="py-2 px-2 text-left">Title</th><th class="py-2 px-2 text-left">Due</th><th class="py-2 px-2 text-left">Priority</th><th class="py-2 px-2 text-left">Checklist</th><th class="py-2 px-2 text-left">Actions</th>';
                echo '</tr></thead><tbody id="taskTableBody-' . $tab . '">';
                foreach ($list as $i => $task) {
                    $progress = count($task->getChecklist()) ? (array_sum(array_column($task->getChecklist(), 'checked')) . '/' . count($task->getChecklist())) : '';
                    $progressVal = count($task->getChecklist()) ? (100 * array_sum(array_column($task->getChecklist(), 'checked')) / count($task->getChecklist())) : 0;
                    echo '<tr class="border-b border-gray-100 dark:border-gray-700">';
                    echo '<td class="py-2 px-2">' . htmlspecialchars($task->getTitle()) . '</td>';
                    echo '<td class="py-2 px-2">' . ($task->getDueDate() ? htmlspecialchars($task->getDueDate()) : '-') . '</td>';
                    echo '<td class="py-2 px-2"><span class="px-2 py-1 rounded text-xs ';
                    if ($task->getPriority() === 'high') echo 'bg-red-200 text-red-800 dark:bg-red-900 dark:text-red-200';
                    elseif ($task->getPriority() === 'low') echo 'bg-green-200 text-green-800 dark:bg-green-900 dark:text-green-200';
                    else echo 'bg-blue-200 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
                    echo '">' . ucfirst($task->getPriority()) . '</span></td>';
                    echo '<td class="py-2 px-2">';
                    if ($progress) {
                        echo '<div class="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-1"><div class="bg-blue-500 h-2.5 rounded-full" style="width:' . $progressVal . '%"></div></div>';
                        echo '<span class="text-xs">' . $progress . '</span>';
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td class="py-2 px-2 flex gap-1">';
                    if ($tab === 'ongoing') echo '<form method="post" style="display:inline"><button title="Mark Done" name="set_done" value="' . $i . '" class="bg-green-500 hover:bg-green-600 text-white px-2 py-1 rounded">✔</button></form>';
                    if ($tab !== 'archived') echo '<form method="post" style="display:inline"><button title="Archive" name="archive" value="' . $i . '" class="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded">🗄</button></form>';
                    echo '<form method="post" style="display:inline"><button title="Delete" name="delete" value="' . $i . '" class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded">✖</button></form>';
                    echo '<button class="edit-btn bg-blue-400 hover:bg-blue-600 text-white px-2 py-1 rounded" data-idx="' . $i . '">✏️</button>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
        // Pomodoro Timer Card
        echo '<div class="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-xl shadow p-6 mt-8 flex flex-col items-center">';
        echo '<h3 class="text-lg font-semibold mb-2">Pomodoro Timer</h3>';
        echo '<div id="pomodoro-timer" class="text-4xl font-mono mb-4">25:00</div>';
        echo '<div class="flex gap-2">';
        echo '<button id="pomodoroStart" class="bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded">Start</button>';
        echo '<button id="pomodoroPause" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-1 rounded">Pause</button>';
        echo '<button id="pomodoroReset" class="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded">Reset</button>';
        echo '</div>';
        echo '</div>';
        break;
    default:
        // Optionally redirect or show a 404
        echo '<h2>Page not found</h2>';
        break;
}
?>
</main>
<footer class="mt-12 py-6 bg-gray-200 dark:bg-gray-900 text-center text-gray-600 dark:text-gray-400 text-sm">
    DayyList Modern App &copy; <?php echo date('Y'); ?> &mdash; Powered by PHP & Tailwind CSS
</footer>
<script>
// Tab switching for tasks page
function switchTab(tab) {
    const url = new URL(window.location.href);
    url.searchParams.set('page', 'tasks');
    url.searchParams.set('tab', tab);
    window.location.href = url.toString();
}
// Dashboard tab switching (no reload)
const dashTabs = document.querySelectorAll('.tabs .tab');
const dashTabContents = document.querySelectorAll('.dashboard-task-tab');
dashTabs.forEach(tab => {
    tab.onclick = function(e) {
        e.preventDefault();
        dashTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const tabName = tab.textContent.toLowerCase();
        dashTabContents.forEach(content => {
            content.style.display = (content.getAttribute('data-tab') === tabName) ? 'block' : 'none';
        });
    };
});
// Modal logic
const openBtn = document.getElementById('openAddModal');
const closeBtn = document.getElementById('closeAddModal');
const modal = document.getElementById('addTaskModal');
if (openBtn && closeBtn && modal) {
    openBtn.onclick = () => modal.classList.add('active');
    closeBtn.onclick = () => modal.classList.remove('active');
    window.onclick = (e) => { if (e.target === modal) modal.classList.remove('active'); };
}
// Add checklist field (tasks page)
const addChecklistBtn = document.getElementById('addChecklistField');
const checklistFields = document.getElementById('checklistFields');
if (addChecklistBtn && checklistFields) {
    addChecklistBtn.onclick = function(e) {
        e.preventDefault();
        const input = document.createElement('input');
        input.name = 'checklist_item[]';
        input.placeholder = 'Checklist item';
        checklistFields.appendChild(input);
    };
}
// Dashboard Add checklist field
const dashboardAddChecklistBtn = document.getElementById('dashboardAddChecklistField');
const dashboardChecklistFields = document.getElementById('dashboardChecklistFields');
if (dashboardAddChecklistBtn && dashboardChecklistFields) {
    dashboardAddChecklistBtn.onclick = function(e) {
        e.preventDefault();
        const input = document.createElement('input');
        input.name = 'checklist_item[]';
        input.placeholder = 'Checklist item';
        dashboardChecklistFields.appendChild(input);
    };
}
// Robust Tailwind dark mode toggle
(function() {
    const darkToggle = document.getElementById('darkModeToggle');
    function setDarkMode(on) {
        if (on) document.body.classList.add('dark');
        else document.body.classList.remove('dark');
        localStorage.setItem('darkMode', !!on);
    }
    if (darkToggle) {
        darkToggle.onclick = function() {
            setDarkMode(!document.body.classList.contains('dark'));
        };
    }
    // On page load
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark');
    } else {
        document.body.classList.remove('dark');
    }
})();
// Edit task modal logic
const editBtns = document.querySelectorAll('.edit-btn');
const editModal = document.getElementById('editTaskModal');
const closeEditBtn = document.getElementById('closeEditModal');
const editForm = document.getElementById('editTaskForm');
editBtns.forEach(btn => {
    btn.onclick = function() {
        const idx = btn.getAttribute('data-idx');
        fetch('get_task.php?idx=' + idx)
            .then(res => res.json())
            .then(task => {
                document.getElementById('edit_task_idx').value = idx;
                document.getElementById('edit_task_title').value = task.title;
                document.getElementById('edit_task_due').value = task.dueDate || '';
                document.getElementById('edit_task_priority').value = task.priority;
                document.getElementById('edit_task_category').value = task.category || '';
                // Checklist
                const fields = document.getElementById('editChecklistFields');
                fields.innerHTML = '';
                (task.checklist || []).forEach((item, i) => {
                    const input = document.createElement('input');
                    input.name = 'edit_checklist_item[]';
                    input.value = item.text;
                    fields.appendChild(input);
                    const checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.name = 'edit_checklist_checked['+i+']';
                    checkbox.checked = item.checked;
                    fields.appendChild(checkbox);
                });
                editModal.classList.add('active');
            });
    };
});
if (closeEditBtn && editModal) {
    closeEditBtn.onclick = () => editModal.classList.remove('active');
    window.onclick = (e) => { if (e.target === editModal) editModal.classList.remove('active'); };
}
document.getElementById('addEditChecklistField')?.addEventListener('click', function(e) {
    e.preventDefault();
    const input = document.createElement('input');
    input.name = 'edit_checklist_item[]';
    input.placeholder = 'Checklist item';
    document.getElementById('editChecklistFields').appendChild(input);
});
// Pomodoro Timer
let pomoTime = 25 * 60;
let pomoInterval = null;
const pomoDisplay = document.getElementById('pomodoro-timer');
const pomoStart = document.getElementById('pomodoroStart');
const pomoPause = document.getElementById('pomodoroPause');
const pomoReset = document.getElementById('pomodoroReset');
function updatePomoDisplay() {
    const min = String(Math.floor(pomoTime / 60)).padStart(2, '0');
    const sec = String(pomoTime % 60).padStart(2, '0');
    pomoDisplay.textContent = `${min}:${sec}`;
}
if (pomoStart && pomoPause && pomoReset && pomoDisplay) {
    pomoStart.onclick = function() {
        if (pomoInterval) return;
        pomoInterval = setInterval(() => {
            if (pomoTime > 0) {
                pomoTime--;
                updatePomoDisplay();
            } else {
                clearInterval(pomoInterval);
                pomoInterval = null;
                alert('Pomodoro finished!');
            }
        }, 1000);
    };
    pomoPause.onclick = function() {
        clearInterval(pomoInterval);
        pomoInterval = null;
    };
    pomoReset.onclick = function() {
        clearInterval(pomoInterval);
        pomoInterval = null;
        pomoTime = 25 * 60;
        updatePomoDisplay();
    };
    updatePomoDisplay();
}
// Settings page logic
if (window.location.search.includes('page=settings')) {
    // Load settings from localStorage
    document.getElementById('settingsDarkMode').checked = localStorage.getItem('darkMode') === 'true';
    document.getElementById('settingsDefaultTab').value = localStorage.getItem('defaultTab') || 'ongoing';
    document.getElementById('settingsPomoLength').value = localStorage.getItem('pomoLength') || 25;
    document.getElementById('saveSettings').onclick = function() {
        localStorage.setItem('darkMode', document.getElementById('settingsDarkMode').checked);
        localStorage.setItem('defaultTab', document.getElementById('settingsDefaultTab').value);
        localStorage.setItem('pomoLength', document.getElementById('settingsPomoLength').value);
        alert('Settings saved!');
        if (document.getElementById('settingsDarkMode').checked) document.body.classList.add('dark');
        else document.body.classList.remove('dark');
    };
}
// Use default tab and pomo length on dashboard
if (window.location.search.includes('page=dashboard')) {
    const defaultTab = localStorage.getItem('defaultTab') || 'ongoing';
    const tabs = document.querySelectorAll('.tabs .tab');
    const tabContents = document.querySelectorAll('.dashboard-task-tab');
    tabs.forEach(tab => {
        if (tab.textContent.toLowerCase() === defaultTab) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    tabContents.forEach(content => {
        content.style.display = (content.getAttribute('data-tab') === defaultTab) ? 'block' : 'none';
    });
    // Pomodoro length
    let len = parseInt(localStorage.getItem('pomoLength') || '25');
    if (!isNaN(len) && document.getElementById('pomodoro-timer')) {
        pomoTime = len * 60;
        updatePomoDisplay();
    }
}
// Toast notification logic
function showToast(msg, type) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.className = 'fixed top-6 right-6 z-50 px-4 py-2 rounded shadow-lg text-white font-semibold ' + (type === 'success' ? 'bg-green-500' : 'bg-red-500');
    toast.style.display = 'block';
    setTimeout(() => { toast.style.display = 'none'; }, 2000);
}
// Task search/filter
const taskSearch = document.getElementById('taskSearch');
if (taskSearch) {
    taskSearch.addEventListener('input', function() {
        const val = this.value.toLowerCase();
        document.querySelectorAll('.dashboard-task-tab').forEach(tab => {
            tab.querySelectorAll('tbody tr').forEach(row => {
                const title = row.querySelector('td')?.textContent.toLowerCase() || '';
                row.style.display = title.includes(val) ? '' : 'none';
            });
        });
    });
}
</script>
</body>
</html> 